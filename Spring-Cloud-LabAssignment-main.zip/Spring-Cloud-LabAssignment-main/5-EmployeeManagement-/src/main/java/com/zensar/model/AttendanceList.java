package com.zensar.model;

import java.util.List;

public class AttendanceList {
	public List<Attendance> attendance;

	public List<Attendance> getAttendance() {
		return attendance;
	}

	public void setAttendance(List<Attendance> attendance) {
		this.attendance = attendance;
	}
	
	
	

}
