package com.zensar.model;

import java.util.List;

public class SalaryList {
	public List<Salary> salary;

	public List<Salary> getSalary() {
		return salary;
	}

	public void setSalary(List<Salary> salary) {
		this.salary = salary;
	}
	

}
